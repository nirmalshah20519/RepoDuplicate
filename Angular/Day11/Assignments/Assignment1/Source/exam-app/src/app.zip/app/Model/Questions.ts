export interface Question{
    QuestionID:number,
    Description:string,
    Options:string[],
    Answer:string
}